# SkillForge Tracker

Настольное приложение для отслеживания прокачки навыков. Проект сделан по ТЗ: есть UI, PostgreSQL, бизнес-логика, связанные сущности, seed-данные и сценарии взаимодействия.

## Стек

- Python 3.11+
- Tkinter
- PostgreSQL
- psycopg2

## Подготовка PostgreSQL

Нужно, чтобы PostgreSQL был установлен и запущен локально. Базу можно создать через pgAdmin или через `psql`.

Вариант через `psql`:

```powershell
psql -U postgres
```

```sql
CREATE USER skillforge WITH PASSWORD 'skillforge';
CREATE DATABASE skillforge OWNER skillforge;
\q
```

Если база создается через pgAdmin, используйте такие же значения:

- база данных: `skillforge`
- пользователь: `skillforge`
- пароль: `skillforge`
- порт: `5432`

## Запуск проекта

1. Создать окружение и установить зависимости:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2. Скопировать `.env.example` в `.env`, если настройки PostgreSQL отличаются от стандартных.

3. Создать таблицы и заполнить начальными данными:

```powershell
python scripts/init_db.py
```

Альтернативно можно выполнить SQL-файлы вручную:

```powershell
psql -U skillforge -d skillforge -f db/schema.sql
psql -U skillforge -d skillforge -f db/seed.sql
```

4. Запустить приложение:

```powershell
python -m app.main
```

## Что реализовано

- Главный экран с состоянием пользователя, уровнем, XP, достижениями и журналом событий.
- Список навыков с созданием, просмотром, редактированием и удалением.
- Детальный экран выбранного навыка: задачи, практика, настройки JSONB.
- Экран действий: выполнение задачи, пропуск задачи, добавление практики, добавление новой задачи.
- Бизнес-логика: начисление XP, штрафы, расчет уровня, автоматическая выдача достижений.
- PostgreSQL-схема из 7 таблиц со связями 1:N и N:M, ENUM, JSONB, индексами и ограничениями.

## Проверка бизнес-логики

```powershell
python -m unittest discover -s tests
```
