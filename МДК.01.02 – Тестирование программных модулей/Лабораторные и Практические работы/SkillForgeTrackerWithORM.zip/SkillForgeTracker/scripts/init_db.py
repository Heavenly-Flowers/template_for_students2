from pathlib import Path
import sys

import psycopg2

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from app.config import DB_CONFIG


def run_sql_file(path: Path) -> None:
    with path.open("r", encoding="utf-8") as file:
        sql = file.read()
    with psycopg2.connect(
        host=DB_CONFIG.host,
        port=DB_CONFIG.port,
        dbname=DB_CONFIG.dbname,
        user=DB_CONFIG.user,
        password=DB_CONFIG.password,
    ) as conn:
        with conn.cursor() as cur:
            cur.execute(sql)


def main() -> None:
    run_sql_file(ROOT / "db" / "schema.sql")
    run_sql_file(ROOT / "db" / "seed.sql")
    print("Database schema and seed data were loaded successfully.")


if __name__ == "__main__":
    main()
