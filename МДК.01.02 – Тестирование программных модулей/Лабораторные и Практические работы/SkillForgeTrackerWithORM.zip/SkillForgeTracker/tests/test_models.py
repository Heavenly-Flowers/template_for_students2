import unittest

from sqlalchemy import inspect

from app.models import (
    Achievement,
    EventLog,
    LearningTask,
    PracticeSession,
    Skill,
    User,
    UserAchievement,
)


class OrmModelsTest(unittest.TestCase):
    def test_all_tables_are_mapped(self):
        mapped_tables = {
            User.__tablename__,
            Skill.__tablename__,
            LearningTask.__tablename__,
            PracticeSession.__tablename__,
            Achievement.__tablename__,
            UserAchievement.__tablename__,
            EventLog.__tablename__,
        }
        self.assertEqual(
            mapped_tables,
            {
                "users",
                "skills",
                "learning_tasks",
                "practice_sessions",
                "achievements",
                "user_achievements",
                "event_log",
            },
        )

    def test_relationships_exist(self):
        user_relationships = {item.key for item in inspect(User).relationships}
        skill_relationships = {item.key for item in inspect(Skill).relationships}

        self.assertIn("skills", user_relationships)
        self.assertIn("achievements", user_relationships)
        self.assertIn("tasks", skill_relationships)
        self.assertIn("practice_sessions", skill_relationships)


if __name__ == "__main__":
    unittest.main()
