import unittest

from app.business import calculate_level, completed_task_xp, session_xp, unlocked_achievements


class BusinessLogicTest(unittest.TestCase):
    def test_calculate_level(self):
        self.assertEqual(calculate_level(0), 1)
        self.assertEqual(calculate_level(99), 1)
        self.assertEqual(calculate_level(100), 2)
        self.assertEqual(calculate_level(260), 3)

    def test_completed_task_xp_uses_difficulty_bonus(self):
        self.assertEqual(completed_task_xp(50, 3), 80)

    def test_session_xp_depends_on_mood(self):
        self.assertEqual(session_xp(40, "normal"), 40)
        self.assertEqual(session_xp(40, "hard"), 50)
        self.assertEqual(session_xp(40, "easy"), 34)

    def test_unlocked_achievements_excludes_owned(self):
        achievements = [
            {"code": "first_step", "required_xp": 50},
            {"code": "steady_growth", "required_xp": 150},
            {"code": "legend_path", "required_xp": 700},
        ]
        self.assertEqual(
            unlocked_achievements(180, achievements, {"first_step"}),
            ["steady_growth"],
        )


if __name__ == "__main__":
    unittest.main()
