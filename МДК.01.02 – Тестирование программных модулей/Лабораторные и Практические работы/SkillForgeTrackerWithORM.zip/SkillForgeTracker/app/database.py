from contextlib import contextmanager

import psycopg2
from psycopg2.extras import RealDictCursor

from app.config import DB_CONFIG


@contextmanager
def get_connection():
    conn = psycopg2.connect(
        host=DB_CONFIG.host,
        port=DB_CONFIG.port,
        dbname=DB_CONFIG.dbname,
        user=DB_CONFIG.user,
        password=DB_CONFIG.password,
    )
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def fetch_all(query: str, params: tuple = ()) -> list[dict]:
    with get_connection() as conn, conn.cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute(query, params)
        return list(cur.fetchall())


def fetch_one(query: str, params: tuple = ()) -> dict | None:
    with get_connection() as conn, conn.cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute(query, params)
        row = cur.fetchone()
        return dict(row) if row else None


def execute(query: str, params: tuple = ()) -> None:
    with get_connection() as conn, conn.cursor() as cur:
        cur.execute(query, params)
