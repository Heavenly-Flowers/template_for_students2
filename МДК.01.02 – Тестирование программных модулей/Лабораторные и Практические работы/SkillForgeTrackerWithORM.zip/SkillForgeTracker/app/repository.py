from psycopg2.extras import Json, RealDictCursor

from app.business import calculate_level, completed_task_xp, session_xp
from app.database import fetch_all, fetch_one, get_connection

DEFAULT_USER_ID = 1


def get_dashboard(user_id: int = DEFAULT_USER_ID) -> dict:
    user = fetch_one("SELECT * FROM users WHERE id = %s", (user_id,))
    stats = fetch_one(
        """
        SELECT
            (SELECT COUNT(*) FROM skills WHERE user_id = %s) AS skill_count,
            (
                SELECT COUNT(*)
                FROM learning_tasks t
                JOIN skills s ON s.id = t.skill_id
                WHERE s.user_id = %s AND t.status <> 'completed'
            ) AS open_tasks,
            (
                SELECT COALESCE(SUM(ps.minutes), 0)
                FROM practice_sessions ps
                JOIN skills s ON s.id = ps.skill_id
                WHERE s.user_id = %s
            ) AS total_minutes
        """,
        (user_id, user_id, user_id),
    )
    achievements = fetch_all(
        """
        SELECT a.title, ua.unlocked_at
        FROM user_achievements ua
        JOIN achievements a ON a.id = ua.achievement_id
        WHERE ua.user_id = %s
        ORDER BY ua.unlocked_at DESC
        """,
        (user_id,),
    )
    events = fetch_all(
        """
        SELECT event_type, payload, created_at
        FROM event_log
        WHERE user_id = %s
        ORDER BY created_at DESC
        LIMIT 6
        """,
        (user_id,),
    )
    return {"user": user, "stats": stats, "achievements": achievements, "events": events}


def list_skills(user_id: int = DEFAULT_USER_ID) -> list[dict]:
    return fetch_all(
        """
        SELECT s.*,
               COALESCE(t.open_tasks, 0) AS open_tasks,
               COALESCE(ps.minutes, 0) AS minutes
        FROM skills s
        LEFT JOIN (
            SELECT skill_id, COUNT(*) AS open_tasks
            FROM learning_tasks
            WHERE status <> 'completed'
            GROUP BY skill_id
        ) t ON t.skill_id = s.id
        LEFT JOIN (
            SELECT skill_id, SUM(minutes) AS minutes
            FROM practice_sessions
            GROUP BY skill_id
        ) ps ON ps.skill_id = s.id
        WHERE s.user_id = %s
        ORDER BY s.created_at DESC
        """,
        (user_id,),
    )


def get_skill(skill_id: int) -> dict:
    skill = fetch_one("SELECT * FROM skills WHERE id = %s", (skill_id,))
    tasks = fetch_all(
        "SELECT * FROM learning_tasks WHERE skill_id = %s ORDER BY status, due_date NULLS LAST, id",
        (skill_id,),
    )
    sessions = fetch_all(
        "SELECT * FROM practice_sessions WHERE skill_id = %s ORDER BY started_at DESC LIMIT 8",
        (skill_id,),
    )
    return {"skill": skill, "tasks": tasks, "sessions": sessions}


def create_skill(name: str, category: str, target_level: int, user_id: int = DEFAULT_USER_ID) -> None:
    with get_connection() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO skills (user_id, name, category, target_level, settings)
            VALUES (%s, %s, %s, %s, %s)
            """,
            (user_id, name, category, target_level, Json({"weekly_goal_minutes": 120, "priority": "medium"})),
        )
        cur.execute(
            "INSERT INTO event_log (user_id, event_type, payload) VALUES (%s, 'skill_created', %s)",
            (user_id, Json({"name": name})),
        )


def update_skill(skill_id: int, name: str, category: str, target_level: int) -> None:
    with get_connection() as conn, conn.cursor() as cur:
        cur.execute(
            "UPDATE skills SET name = %s, category = %s, target_level = %s WHERE id = %s",
            (name, category, target_level, skill_id),
        )


def delete_skill(skill_id: int) -> None:
    with get_connection() as conn, conn.cursor() as cur:
        cur.execute("DELETE FROM skills WHERE id = %s", (skill_id,))


def add_task(skill_id: int, title: str, description: str, difficulty: int, xp_reward: int) -> None:
    with get_connection() as conn, conn.cursor() as cur:
        cur.execute(
            """
            INSERT INTO learning_tasks (skill_id, title, description, difficulty, xp_reward, status)
            VALUES (%s, %s, %s, %s, %s, 'active')
            """,
            (skill_id, title, description, difficulty, xp_reward),
        )


def complete_task(task_id: int, user_id: int = DEFAULT_USER_ID) -> int:
    with get_connection() as conn, conn.cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute("SELECT * FROM learning_tasks WHERE id = %s FOR UPDATE", (task_id,))
        task = cur.fetchone()
        if not task or task["status"] == "completed":
            return 0
        gained = completed_task_xp(task["xp_reward"], task["difficulty"])
        cur.execute("UPDATE learning_tasks SET status = 'completed' WHERE id = %s", (task_id,))
        _apply_xp(cur, user_id, task["skill_id"], gained, "task_completed", {"task": task["title"]})
        return gained


def skip_task(task_id: int, user_id: int = DEFAULT_USER_ID) -> int:
    with get_connection() as conn, conn.cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute("SELECT * FROM learning_tasks WHERE id = %s FOR UPDATE", (task_id,))
        task = cur.fetchone()
        if not task or task["status"] == "completed":
            return 0
        penalty = min(25, task["xp_reward"] // 3)
        cur.execute("UPDATE learning_tasks SET status = 'skipped' WHERE id = %s", (task_id,))
        cur.execute("UPDATE users SET xp = GREATEST(0, xp - %s) WHERE id = %s", (penalty, user_id))
        cur.execute(
            "INSERT INTO event_log (user_id, skill_id, event_type, payload) VALUES (%s, %s, %s, %s)",
            (user_id, task["skill_id"], "task_skipped", Json({"task": task["title"], "penalty": penalty})),
        )
        return penalty


def add_practice(skill_id: int, minutes: int, mood: str, notes: str, user_id: int = DEFAULT_USER_ID) -> int:
    gained = session_xp(minutes, mood)
    with get_connection() as conn, conn.cursor(cursor_factory=RealDictCursor) as cur:
        cur.execute(
            """
            INSERT INTO practice_sessions (skill_id, minutes, mood, notes)
            VALUES (%s, %s, %s, %s)
            """,
            (skill_id, minutes, mood, notes),
        )
        _apply_xp(cur, user_id, skill_id, gained, "practice_added", {"minutes": minutes, "mood": mood})
    return gained


def _apply_xp(cur, user_id: int, skill_id: int, xp: int, event_type: str, payload: dict) -> None:
    cur.execute("UPDATE skills SET current_xp = current_xp + %s WHERE id = %s", (xp, skill_id))
    cur.execute("UPDATE users SET xp = xp + %s WHERE id = %s RETURNING xp", (xp, user_id))
    total_xp = cur.fetchone()["xp"]
    cur.execute("UPDATE users SET level = %s WHERE id = %s", (calculate_level(total_xp), user_id))
    cur.execute(
        "INSERT INTO event_log (user_id, skill_id, event_type, payload) VALUES (%s, %s, %s, %s)",
        (user_id, skill_id, event_type, Json({"xp": xp, **payload})),
    )
    cur.execute(
        """
        INSERT INTO user_achievements (user_id, achievement_id)
        SELECT %s, id
        FROM achievements
        WHERE required_xp <= %s
        ON CONFLICT DO NOTHING
        """,
        (user_id, total_xp),
    )
