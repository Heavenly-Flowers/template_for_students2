from collections.abc import Iterator
from contextlib import contextmanager

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.config import DB_CONFIG


def build_database_url() -> str:
    return (
        f"postgresql+psycopg2://{DB_CONFIG.user}:{DB_CONFIG.password}"
        f"@{DB_CONFIG.host}:{DB_CONFIG.port}/{DB_CONFIG.dbname}"
    )


engine = create_engine(build_database_url(), echo=False, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


@contextmanager
def get_session() -> Iterator[Session]:
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
