from dataclasses import dataclass


XP_PER_LEVEL = 100


@dataclass(frozen=True)
class ProgressResult:
    added_xp: int
    total_xp: int
    level: int
    unlocked_codes: list[str]


def calculate_level(total_xp: int) -> int:
    return max(1, total_xp // XP_PER_LEVEL + 1)


def session_xp(minutes: int, mood: str) -> int:
    mood_bonus = {"hard": 1.25, "normal": 1.0, "easy": 0.85}
    return max(5, round(minutes * mood_bonus.get(mood, 1.0)))


def completed_task_xp(base_reward: int, difficulty: int) -> int:
    return base_reward + difficulty * 10


def unlocked_achievements(total_xp: int, achievements: list[dict], owned_codes: set[str]) -> list[str]:
    return [
        item["code"]
        for item in achievements
        if item["required_xp"] <= total_xp and item["code"] not in owned_codes
    ]
