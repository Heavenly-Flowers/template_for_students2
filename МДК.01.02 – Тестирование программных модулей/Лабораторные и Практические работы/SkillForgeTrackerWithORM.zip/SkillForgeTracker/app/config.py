import os
from dataclasses import dataclass

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None


if load_dotenv:
    load_dotenv()


@dataclass(frozen=True)
class DbConfig:
    host: str = os.getenv("DB_HOST", "localhost")
    port: int = int(os.getenv("DB_PORT", "5432"))
    dbname: str = os.getenv("DB_NAME", "skillforge")
    user: str = os.getenv("DB_USER", "skillforge")
    password: str = os.getenv("DB_PASSWORD", "skillforge")


DB_CONFIG = DbConfig()
