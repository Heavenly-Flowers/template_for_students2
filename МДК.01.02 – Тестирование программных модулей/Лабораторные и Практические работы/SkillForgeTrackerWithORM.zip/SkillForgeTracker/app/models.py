from __future__ import annotations

import enum
from datetime import date, datetime

from sqlalchemy import CheckConstraint, Date, DateTime, ForeignKey, Index, Integer, String, Text, UniqueConstraint, func
from sqlalchemy.dialects.postgresql import ENUM, JSONB
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


class SkillCategory(str, enum.Enum):
    programming = "programming"
    design = "design"
    language = "language"
    career = "career"
    health = "health"
    creative = "creative"


class TaskStatus(str, enum.Enum):
    planned = "planned"
    active = "active"
    completed = "completed"
    skipped = "skipped"


class SessionMood(str, enum.Enum):
    hard = "hard"
    normal = "normal"
    easy = "easy"


skill_category_enum = ENUM(SkillCategory, name="skill_category", create_type=False)
task_status_enum = ENUM(TaskStatus, name="task_status", create_type=False)
session_mood_enum = ENUM(SessionMood, name="session_mood", create_type=False)


class User(Base):
    __tablename__ = "users"
    __table_args__ = (
        CheckConstraint("level >= 1", name="users_level_check"),
        CheckConstraint("xp >= 0", name="users_xp_check"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(40), nullable=False, unique=True)
    full_name: Mapped[str] = mapped_column(String(120), nullable=False)
    level: Mapped[int] = mapped_column(Integer, nullable=False, default=1)
    xp: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, server_default=func.current_timestamp())

    skills: Mapped[list[Skill]] = relationship(back_populates="user", cascade="all, delete-orphan")
    achievements: Mapped[list[UserAchievement]] = relationship(back_populates="user", cascade="all, delete-orphan")
    events: Mapped[list[EventLog]] = relationship(back_populates="user", cascade="all, delete-orphan")


class Skill(Base):
    __tablename__ = "skills"
    __table_args__ = (
        CheckConstraint("target_level BETWEEN 1 AND 20", name="skills_target_level_check"),
        CheckConstraint("current_xp >= 0", name="skills_current_xp_check"),
        UniqueConstraint("user_id", "name", name="skills_user_id_name_key"),
        Index("idx_skills_user_id", "user_id"),
        Index("idx_skills_settings_gin", "settings", postgresql_using="gin"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    name: Mapped[str] = mapped_column(String(80), nullable=False)
    category: Mapped[SkillCategory] = mapped_column(skill_category_enum, nullable=False)
    target_level: Mapped[int] = mapped_column(Integer, nullable=False)
    current_xp: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    settings: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict, server_default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, server_default=func.current_timestamp())

    user: Mapped[User] = relationship(back_populates="skills")
    tasks: Mapped[list[LearningTask]] = relationship(back_populates="skill", cascade="all, delete-orphan")
    practice_sessions: Mapped[list[PracticeSession]] = relationship(back_populates="skill", cascade="all, delete-orphan")
    events: Mapped[list[EventLog]] = relationship(back_populates="skill")


class LearningTask(Base):
    __tablename__ = "learning_tasks"
    __table_args__ = (
        CheckConstraint("difficulty BETWEEN 1 AND 5", name="learning_tasks_difficulty_check"),
        CheckConstraint("xp_reward BETWEEN 5 AND 250", name="learning_tasks_xp_reward_check"),
        UniqueConstraint("skill_id", "title", name="learning_tasks_skill_id_title_key"),
        Index("idx_tasks_skill_status", "skill_id", "status"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    skill_id: Mapped[int] = mapped_column(ForeignKey("skills.id", ondelete="CASCADE"), nullable=False)
    title: Mapped[str] = mapped_column(String(140), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    difficulty: Mapped[int] = mapped_column(Integer, nullable=False)
    xp_reward: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[TaskStatus] = mapped_column(task_status_enum, nullable=False, default=TaskStatus.planned)
    due_date: Mapped[date | None] = mapped_column(Date)

    skill: Mapped[Skill] = relationship(back_populates="tasks")


class PracticeSession(Base):
    __tablename__ = "practice_sessions"
    __table_args__ = (
        CheckConstraint("minutes BETWEEN 5 AND 480", name="practice_sessions_minutes_check"),
        Index("idx_sessions_skill_started", "skill_id", "started_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    skill_id: Mapped[int] = mapped_column(ForeignKey("skills.id", ondelete="CASCADE"), nullable=False)
    started_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, server_default=func.current_timestamp())
    minutes: Mapped[int] = mapped_column(Integer, nullable=False)
    mood: Mapped[SessionMood] = mapped_column(session_mood_enum, nullable=False)
    notes: Mapped[str] = mapped_column(Text, nullable=False, default="", server_default="")

    skill: Mapped[Skill] = relationship(back_populates="practice_sessions")


class Achievement(Base):
    __tablename__ = "achievements"
    __table_args__ = (
        CheckConstraint("required_xp >= 0", name="achievements_required_xp_check"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    code: Mapped[str] = mapped_column(String(50), nullable=False, unique=True)
    title: Mapped[str] = mapped_column(String(100), nullable=False)
    description: Mapped[str] = mapped_column(Text, nullable=False)
    required_xp: Mapped[int] = mapped_column(Integer, nullable=False)

    users: Mapped[list[UserAchievement]] = relationship(back_populates="achievement", cascade="all, delete-orphan")


class UserAchievement(Base):
    __tablename__ = "user_achievements"

    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    achievement_id: Mapped[int] = mapped_column(ForeignKey("achievements.id", ondelete="CASCADE"), primary_key=True)
    unlocked_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, server_default=func.current_timestamp())

    user: Mapped[User] = relationship(back_populates="achievements")
    achievement: Mapped[Achievement] = relationship(back_populates="users")


class EventLog(Base):
    __tablename__ = "event_log"
    __table_args__ = (
        Index("idx_events_user_created", "user_id", "created_at"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    skill_id: Mapped[int | None] = mapped_column(ForeignKey("skills.id", ondelete="SET NULL"))
    event_type: Mapped[str] = mapped_column(String(50), nullable=False)
    payload: Mapped[dict] = mapped_column(JSONB, nullable=False, default=dict, server_default="{}")
    created_at: Mapped[datetime] = mapped_column(DateTime, nullable=False, server_default=func.current_timestamp())

    user: Mapped[User] = relationship(back_populates="events")
    skill: Mapped[Skill | None] = relationship(back_populates="events")
