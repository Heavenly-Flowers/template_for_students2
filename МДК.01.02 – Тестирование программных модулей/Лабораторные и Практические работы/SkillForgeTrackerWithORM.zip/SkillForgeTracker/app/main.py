import tkinter as tk
from tkinter import messagebox, ttk

from app import repository as repo

CATEGORIES = ("programming", "design", "language", "career", "health", "creative")
MOODS = ("hard", "normal", "easy")


class SkillForgeApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SkillForge Tracker")
        self.geometry("1060x680")
        self.minsize(920, 600)
        self.configure(bg="#f6f7f9")
        self.selected_skill_id = None
        self._setup_style()
        self._build_layout()
        self.refresh_all()

    def _setup_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TFrame", background="#f6f7f9")
        style.configure("Panel.TFrame", background="#ffffff", borderwidth=1, relief="solid")
        style.configure("TLabel", background="#f6f7f9", foreground="#20242a", font=("Segoe UI", 10))
        style.configure("Panel.TLabel", background="#ffffff", foreground="#20242a", font=("Segoe UI", 10))
        style.configure("Title.TLabel", background="#ffffff", font=("Segoe UI Semibold", 18))
        style.configure("Metric.TLabel", background="#ffffff", font=("Segoe UI Semibold", 13))
        style.configure("TButton", font=("Segoe UI", 10), padding=7)
        style.configure("Treeview", font=("Segoe UI", 10), rowheight=28)
        style.configure("Treeview.Heading", font=("Segoe UI Semibold", 10))

    def _build_layout(self):
        nav = ttk.Frame(self, padding=12)
        nav.pack(side=tk.LEFT, fill=tk.Y)
        ttk.Label(nav, text="SkillForge", font=("Segoe UI Semibold", 20)).pack(anchor="w", pady=(0, 18))
        ttk.Button(nav, text="Обзор", command=lambda: self.show_page("dashboard")).pack(fill=tk.X, pady=4)
        ttk.Button(nav, text="Навыки", command=lambda: self.show_page("skills")).pack(fill=tk.X, pady=4)
        ttk.Button(nav, text="Действия", command=lambda: self.show_page("actions")).pack(fill=tk.X, pady=4)
        ttk.Button(nav, text="Обновить", command=self.refresh_all).pack(fill=tk.X, pady=(24, 4))

        self.container = ttk.Frame(self, padding=16)
        self.container.pack(side=tk.RIGHT, expand=True, fill=tk.BOTH)
        self.pages = {}
        self._dashboard_page()
        self._skills_page()
        self._actions_page()

    def _panel(self, parent):
        return ttk.Frame(parent, style="Panel.TFrame", padding=14)

    def _dashboard_page(self):
        page = ttk.Frame(self.container)
        self.pages["dashboard"] = page
        self.dashboard_title = ttk.Label(page, text="", style="Title.TLabel")
        top = self._panel(page)
        top.pack(fill=tk.X)
        self.dashboard_title.pack(in_=top, anchor="w")
        self.metrics = ttk.Label(top, text="", style="Metric.TLabel")
        self.metrics.pack(anchor="w", pady=(10, 0))
        lower = ttk.Frame(page)
        lower.pack(expand=True, fill=tk.BOTH, pady=(14, 0))
        left = self._panel(lower)
        right = self._panel(lower)
        left.pack(side=tk.LEFT, expand=True, fill=tk.BOTH, padx=(0, 7))
        right.pack(side=tk.RIGHT, expand=True, fill=tk.BOTH, padx=(7, 0))
        ttk.Label(left, text="Последние события", style="Title.TLabel").pack(anchor="w")
        self.events_box = tk.Listbox(left, borderwidth=0, font=("Segoe UI", 10), activestyle="none")
        self.events_box.pack(expand=True, fill=tk.BOTH, pady=(10, 0))
        ttk.Label(right, text="Достижения", style="Title.TLabel").pack(anchor="w")
        self.achievements_box = tk.Listbox(right, borderwidth=0, font=("Segoe UI", 10), activestyle="none")
        self.achievements_box.pack(expand=True, fill=tk.BOTH, pady=(10, 0))

    def _skills_page(self):
        page = ttk.Frame(self.container)
        self.pages["skills"] = page
        toolbar = ttk.Frame(page)
        toolbar.pack(fill=tk.X, pady=(0, 10))
        ttk.Label(toolbar, text="Навыки", font=("Segoe UI Semibold", 18)).pack(side=tk.LEFT)
        ttk.Button(toolbar, text="Добавить", command=self.open_skill_form).pack(side=tk.RIGHT, padx=4)
        ttk.Button(toolbar, text="Изменить", command=self.edit_selected_skill).pack(side=tk.RIGHT, padx=4)
        ttk.Button(toolbar, text="Удалить", command=self.delete_selected_skill).pack(side=tk.RIGHT, padx=4)
        columns = ("name", "category", "target", "xp", "tasks", "minutes")
        self.skills_tree = ttk.Treeview(page, columns=columns, show="headings", height=10)
        headings = ("Название", "Категория", "Цель", "XP", "Открыто задач", "Минуты")
        widths = (230, 130, 80, 80, 110, 90)
        for col, text, width in zip(columns, headings, widths):
            self.skills_tree.heading(col, text=text)
            self.skills_tree.column(col, width=width, anchor=tk.W)
        self.skills_tree.pack(fill=tk.BOTH, expand=True)
        self.skills_tree.bind("<<TreeviewSelect>>", self.on_skill_select)

        detail = self._panel(page)
        detail.pack(fill=tk.BOTH, pady=(10, 0))
        self.detail_text = tk.Text(detail, height=10, wrap=tk.WORD, borderwidth=0, font=("Segoe UI", 10))
        self.detail_text.pack(expand=True, fill=tk.BOTH)

    def _actions_page(self):
        page = ttk.Frame(self.container)
        self.pages["actions"] = page
        ttk.Label(page, text="Взаимодействие", font=("Segoe UI Semibold", 18)).pack(anchor="w", pady=(0, 10))
        body = ttk.Frame(page)
        body.pack(expand=True, fill=tk.BOTH)
        left = self._panel(body)
        right = self._panel(body)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 7))
        right.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(7, 0))

        ttk.Label(left, text="Задачи выбранного навыка", style="Title.TLabel").pack(anchor="w")
        self.tasks_tree = ttk.Treeview(left, columns=("title", "status", "difficulty", "xp"), show="headings", height=12)
        for col, text, width in (("title", "Задача", 240), ("status", "Статус", 95), ("difficulty", "Сложн.", 70), ("xp", "XP", 60)):
            self.tasks_tree.heading(col, text=text)
            self.tasks_tree.column(col, width=width)
        self.tasks_tree.pack(expand=True, fill=tk.BOTH, pady=8)
        ttk.Button(left, text="Выполнить задачу", command=self.complete_selected_task).pack(side=tk.LEFT, padx=4)
        ttk.Button(left, text="Пропустить", command=self.skip_selected_task).pack(side=tk.LEFT, padx=4)

        ttk.Label(right, text="Новая практика", style="Title.TLabel").pack(anchor="w")
        self.minutes_var = tk.StringVar(value="30")
        self.mood_var = tk.StringVar(value="normal")
        self.notes_var = tk.StringVar()
        form = ttk.Frame(right, style="Panel.TFrame")
        form.pack(fill=tk.X, pady=10)
        ttk.Label(form, text="Минуты", style="Panel.TLabel").grid(row=0, column=0, sticky="w", pady=5)
        ttk.Entry(form, textvariable=self.minutes_var).grid(row=0, column=1, sticky="ew", pady=5)
        ttk.Label(form, text="Настроение", style="Panel.TLabel").grid(row=1, column=0, sticky="w", pady=5)
        ttk.Combobox(form, textvariable=self.mood_var, values=MOODS, state="readonly").grid(row=1, column=1, sticky="ew", pady=5)
        ttk.Label(form, text="Заметка", style="Panel.TLabel").grid(row=2, column=0, sticky="w", pady=5)
        ttk.Entry(form, textvariable=self.notes_var).grid(row=2, column=1, sticky="ew", pady=5)
        form.columnconfigure(1, weight=1)
        ttk.Button(right, text="Записать практику", command=self.add_practice).pack(anchor="w")

        ttk.Separator(right).pack(fill=tk.X, pady=18)
        ttk.Label(right, text="Новая задача", style="Title.TLabel").pack(anchor="w")
        self.task_title_var = tk.StringVar()
        self.task_desc_var = tk.StringVar()
        self.task_diff_var = tk.StringVar(value="3")
        self.task_xp_var = tk.StringVar(value="50")
        task_form = ttk.Frame(right, style="Panel.TFrame")
        task_form.pack(fill=tk.X, pady=10)
        for row, (label, var) in enumerate((
            ("Название", self.task_title_var),
            ("Описание", self.task_desc_var),
            ("Сложность 1-5", self.task_diff_var),
            ("Награда XP", self.task_xp_var),
        )):
            ttk.Label(task_form, text=label, style="Panel.TLabel").grid(row=row, column=0, sticky="w", pady=5)
            ttk.Entry(task_form, textvariable=var).grid(row=row, column=1, sticky="ew", pady=5)
        task_form.columnconfigure(1, weight=1)
        ttk.Button(right, text="Добавить задачу", command=self.add_task).pack(anchor="w")

    def show_page(self, name: str):
        for page in self.pages.values():
            page.pack_forget()
        self.pages[name].pack(expand=True, fill=tk.BOTH)

    def refresh_all(self):
        try:
            self.refresh_dashboard()
            self.refresh_skills()
            self.show_page("dashboard")
        except Exception as exc:
            messagebox.showerror("Нет подключения к БД", f"Проверьте PostgreSQL и настройки .env.\n\n{exc}")

    def refresh_dashboard(self):
        data = repo.get_dashboard()
        user = data["user"]
        stats = data["stats"]
        self.dashboard_title.configure(text=f"{user['full_name']} - уровень {user['level']}, {user['xp']} XP")
        self.metrics.configure(
            text=f"Навыков: {stats['skill_count']}    Открытых задач: {stats['open_tasks']}    Минут практики: {stats['total_minutes']}"
        )
        self.events_box.delete(0, tk.END)
        for event in data["events"]:
            self.events_box.insert(tk.END, f"{event['created_at']:%d.%m %H:%M} - {event['event_type']} - {dict(event['payload'])}")
        self.achievements_box.delete(0, tk.END)
        for item in data["achievements"]:
            self.achievements_box.insert(tk.END, f"{item['title']} - {item['unlocked_at']:%d.%m.%Y}")

    def refresh_skills(self):
        for row in self.skills_tree.get_children():
            self.skills_tree.delete(row)
        for skill in repo.list_skills():
            self.skills_tree.insert(
                "", tk.END, iid=str(skill["id"]),
                values=(skill["name"], skill["category"], skill["target_level"], skill["current_xp"], skill["open_tasks"], skill["minutes"]),
            )
        self.refresh_detail()

    def on_skill_select(self, _event=None):
        selected = self.skills_tree.selection()
        self.selected_skill_id = int(selected[0]) if selected else None
        self.refresh_detail()

    def refresh_detail(self):
        self.detail_text.delete("1.0", tk.END)
        for row in self.tasks_tree.get_children():
            self.tasks_tree.delete(row)
        if not self.selected_skill_id:
            self.detail_text.insert(tk.END, "Выберите навык, чтобы увидеть детали, задачи и практику.")
            return
        data = repo.get_skill(self.selected_skill_id)
        skill = data["skill"]
        self.detail_text.insert(tk.END, f"{skill['name']}\nКатегория: {skill['category']}\nЦель: уровень {skill['target_level']}\nXP навыка: {skill['current_xp']}\nНастройки: {dict(skill['settings'])}\n\nЗадачи:\n")
        for task in data["tasks"]:
            self.detail_text.insert(tk.END, f"- {task['title']} [{task['status']}], XP {task['xp_reward']}, сложность {task['difficulty']}\n")
            self.tasks_tree.insert("", tk.END, iid=str(task["id"]), values=(task["title"], task["status"], task["difficulty"], task["xp_reward"]))
        self.detail_text.insert(tk.END, "\nПоследняя практика:\n")
        for session in data["sessions"]:
            self.detail_text.insert(tk.END, f"- {session['started_at']:%d.%m.%Y %H:%M}: {session['minutes']} мин., {session['mood']}; {session['notes']}\n")

    def open_skill_form(self, existing=None):
        window = tk.Toplevel(self)
        window.title("Навык")
        window.geometry("360x220")
        name_var = tk.StringVar(value=existing["name"] if existing else "")
        category_var = tk.StringVar(value=existing["category"] if existing else CATEGORIES[0])
        target_var = tk.StringVar(value=str(existing["target_level"] if existing else 5))
        frame = ttk.Frame(window, padding=14)
        frame.pack(expand=True, fill=tk.BOTH)
        for row, (label, widget) in enumerate((
            ("Название", ttk.Entry(frame, textvariable=name_var)),
            ("Категория", ttk.Combobox(frame, textvariable=category_var, values=CATEGORIES, state="readonly")),
            ("Целевой уровень", ttk.Entry(frame, textvariable=target_var)),
        )):
            ttk.Label(frame, text=label).grid(row=row, column=0, sticky="w", pady=6)
            widget.grid(row=row, column=1, sticky="ew", pady=6)
        frame.columnconfigure(1, weight=1)

        def save():
            try:
                target = int(target_var.get())
                if existing:
                    repo.update_skill(existing["id"], name_var.get().strip(), category_var.get(), target)
                else:
                    repo.create_skill(name_var.get().strip(), category_var.get(), target)
                window.destroy()
                self.refresh_all()
                self.show_page("skills")
            except Exception as exc:
                messagebox.showerror("Ошибка", str(exc))

        ttk.Button(frame, text="Сохранить", command=save).grid(row=3, column=1, sticky="e", pady=12)

    def edit_selected_skill(self):
        if not self.selected_skill_id:
            messagebox.showinfo("Навык", "Сначала выберите навык.")
            return
        self.open_skill_form(repo.get_skill(self.selected_skill_id)["skill"])

    def delete_selected_skill(self):
        if not self.selected_skill_id:
            messagebox.showinfo("Навык", "Сначала выберите навык.")
            return
        if messagebox.askyesno("Удаление", "Удалить выбранный навык со всеми задачами и практикой?"):
            repo.delete_skill(self.selected_skill_id)
            self.selected_skill_id = None
            self.refresh_all()
            self.show_page("skills")

    def complete_selected_task(self):
        task_id = self._selected_task_id()
        if task_id:
            gained = repo.complete_task(task_id)
            messagebox.showinfo("Готово", f"Задача выполнена. Начислено {gained} XP.")
            self.refresh_all()
            self.show_page("actions")

    def skip_selected_task(self):
        task_id = self._selected_task_id()
        if task_id:
            penalty = repo.skip_task(task_id)
            messagebox.showinfo("Пропуск", f"Задача пропущена. Штраф {penalty} XP.")
            self.refresh_all()
            self.show_page("actions")

    def _selected_task_id(self):
        selected = self.tasks_tree.selection()
        if not selected:
            messagebox.showinfo("Задача", "Сначала выберите задачу.")
            return None
        return int(selected[0])

    def add_practice(self):
        if not self.selected_skill_id:
            messagebox.showinfo("Практика", "Сначала выберите навык на экране навыков.")
            return
        try:
            gained = repo.add_practice(self.selected_skill_id, int(self.minutes_var.get()), self.mood_var.get(), self.notes_var.get().strip())
            self.notes_var.set("")
            messagebox.showinfo("Практика", f"Запись сохранена. Начислено {gained} XP.")
            self.refresh_all()
            self.show_page("actions")
        except Exception as exc:
            messagebox.showerror("Ошибка", str(exc))

    def add_task(self):
        if not self.selected_skill_id:
            messagebox.showinfo("Задача", "Сначала выберите навык на экране навыков.")
            return
        try:
            repo.add_task(
                self.selected_skill_id,
                self.task_title_var.get().strip(),
                self.task_desc_var.get().strip() or "Практическое задание по развитию навыка.",
                int(self.task_diff_var.get()),
                int(self.task_xp_var.get()),
            )
            self.task_title_var.set("")
            self.task_desc_var.set("")
            self.refresh_all()
            self.show_page("actions")
        except Exception as exc:
            messagebox.showerror("Ошибка", str(exc))


if __name__ == "__main__":
    SkillForgeApp().mainloop()
