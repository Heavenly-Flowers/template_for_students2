"""SkillForge Tracker desktop application."""
