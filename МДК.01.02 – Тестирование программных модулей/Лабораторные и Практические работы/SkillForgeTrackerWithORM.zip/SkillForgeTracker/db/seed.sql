INSERT INTO users (username, full_name, level, xp) VALUES
('student', 'Ivan Petrov', 2, 160);

INSERT INTO achievements (code, title, description, required_xp) VALUES
('first_step', 'Первый шаг', 'Получить первые 50 XP за обучение.', 50),
('steady_growth', 'Стабильный рост', 'Накопить 150 XP.', 150),
('focused_master', 'Фокус-мастер', 'Накопить 350 XP.', 350),
('legend_path', 'Путь легенды', 'Накопить 700 XP.', 700);

INSERT INTO skills (user_id, name, category, target_level, current_xp, settings) VALUES
(1, 'Python для автоматизации', 'programming', 8, 110, '{"weekly_goal_minutes": 240, "priority": "high"}'),
(1, 'Английский для IT', 'language', 6, 50, '{"weekly_goal_minutes": 180, "priority": "medium"}'),
(1, 'UI-прототипирование', 'design', 5, 0, '{"weekly_goal_minutes": 120, "priority": "low"}');

INSERT INTO learning_tasks (skill_id, title, description, difficulty, xp_reward, status, due_date) VALUES
(1, 'Написать CLI-скрипт', 'Сделать консольную утилиту для сортировки файлов по папкам.', 3, 60, 'active', CURRENT_DATE + INTERVAL '3 days'),
(1, 'Разобрать работу с PostgreSQL', 'Создать таблицы, связи, ограничения и выполнить несколько запросов.', 4, 80, 'planned', CURRENT_DATE + INTERVAL '6 days'),
(2, 'Выучить 30 технических слов', 'Составить карточки по темам backend, UI, database.', 2, 35, 'active', CURRENT_DATE + INTERVAL '2 days'),
(3, 'Собрать экран профиля навыка', 'Нарисовать компактный экран деталей и действий.', 3, 55, 'planned', CURRENT_DATE + INTERVAL '5 days');

INSERT INTO practice_sessions (skill_id, minutes, mood, notes) VALUES
(1, 45, 'normal', 'Повторены функции и работа с файлами.'),
(2, 30, 'easy', 'Карточки vocabulary прошли без ошибок.');

INSERT INTO user_achievements (user_id, achievement_id)
SELECT 1, id FROM achievements WHERE required_xp <= 160;

INSERT INTO event_log (user_id, skill_id, event_type, payload) VALUES
(1, 1, 'seed_progress', '{"message": "Начальный прогресс по Python"}'),
(1, 2, 'seed_progress', '{"message": "Добавлена регулярная языковая практика"}');
