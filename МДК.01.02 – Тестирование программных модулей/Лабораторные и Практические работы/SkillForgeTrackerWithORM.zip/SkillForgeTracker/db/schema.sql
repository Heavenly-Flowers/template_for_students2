DROP TABLE IF EXISTS event_log CASCADE;
DROP TABLE IF EXISTS user_achievements CASCADE;
DROP TABLE IF EXISTS achievements CASCADE;
DROP TABLE IF EXISTS practice_sessions CASCADE;
DROP TABLE IF EXISTS learning_tasks CASCADE;
DROP TABLE IF EXISTS skills CASCADE;
DROP TABLE IF EXISTS users CASCADE;

DROP TYPE IF EXISTS skill_category;
DROP TYPE IF EXISTS task_status;
DROP TYPE IF EXISTS session_mood;

CREATE TYPE skill_category AS ENUM ('programming', 'design', 'language', 'career', 'health', 'creative');
CREATE TYPE task_status AS ENUM ('planned', 'active', 'completed', 'skipped');
CREATE TYPE session_mood AS ENUM ('hard', 'normal', 'easy');

CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(40) NOT NULL UNIQUE,
    full_name VARCHAR(120) NOT NULL,
    level INTEGER NOT NULL DEFAULT 1 CHECK (level >= 1),
    xp INTEGER NOT NULL DEFAULT 0 CHECK (xp >= 0),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE skills (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(80) NOT NULL,
    category skill_category NOT NULL,
    target_level INTEGER NOT NULL CHECK (target_level BETWEEN 1 AND 20),
    current_xp INTEGER NOT NULL DEFAULT 0 CHECK (current_xp >= 0),
    settings JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, name)
);

CREATE TABLE learning_tasks (
    id SERIAL PRIMARY KEY,
    skill_id INTEGER NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
    title VARCHAR(140) NOT NULL,
    description TEXT NOT NULL,
    difficulty INTEGER NOT NULL CHECK (difficulty BETWEEN 1 AND 5),
    xp_reward INTEGER NOT NULL CHECK (xp_reward BETWEEN 5 AND 250),
    status task_status NOT NULL DEFAULT 'planned',
    due_date DATE,
    UNIQUE (skill_id, title)
);

CREATE TABLE practice_sessions (
    id SERIAL PRIMARY KEY,
    skill_id INTEGER NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
    started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    minutes INTEGER NOT NULL CHECK (minutes BETWEEN 5 AND 480),
    mood session_mood NOT NULL,
    notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE achievements (
    id SERIAL PRIMARY KEY,
    code VARCHAR(50) NOT NULL UNIQUE,
    title VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    required_xp INTEGER NOT NULL CHECK (required_xp >= 0)
);

CREATE TABLE user_achievements (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    achievement_id INTEGER NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
    unlocked_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, achievement_id)
);

CREATE TABLE event_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    skill_id INTEGER REFERENCES skills(id) ON DELETE SET NULL,
    event_type VARCHAR(50) NOT NULL,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_skills_user_id ON skills(user_id);
CREATE INDEX idx_tasks_skill_status ON learning_tasks(skill_id, status);
CREATE INDEX idx_sessions_skill_started ON practice_sessions(skill_id, started_at DESC);
CREATE INDEX idx_events_user_created ON event_log(user_id, created_at DESC);
CREATE INDEX idx_skills_settings_gin ON skills USING GIN(settings);
