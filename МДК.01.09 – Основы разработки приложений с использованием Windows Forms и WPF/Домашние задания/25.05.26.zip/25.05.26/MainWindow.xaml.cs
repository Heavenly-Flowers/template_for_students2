﻿using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;

namespace NotesApp;

public partial class MainWindow : Window
{
    private readonly ObservableCollection<Note> notes = new();
    private string filePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "SimpleWpfNotes", "notes.json");

    public MainWindow()
    {
        InitializeComponent();
        NotesList.ItemsSource = notes;
        DateBox.SelectedDate = DateTime.Today;
        LoadNotes();
    }

    private void LoadNotes()
    {
        try
        {
            if (File.Exists(filePath))
            {
                var savedNotes = JsonSerializer.Deserialize<List<Note>>(File.ReadAllText(filePath));
                if (savedNotes != null)
                    foreach (Note note in savedNotes)
                        notes.Add(note);
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or JsonException)
        {
            MessageBox.Show("Не удалось загрузить заметки.", "Заметки");
        }
    }

    private void SaveNotes()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);
            File.WriteAllText(filePath, JsonSerializer.Serialize(notes));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            MessageBox.Show("Не удалось сохранить заметки в файл.", "Заметки");
        }
    }

    private bool CheckTitle()
    {
        if (!string.IsNullOrWhiteSpace(TitleBox.Text))
            return true;

        MessageBox.Show("Введите заголовок заметки.", "Заметки");
        return false;
    }

    private void Add_Click(object sender, RoutedEventArgs e)
    {
        if (!CheckTitle())
            return;

        Note note = new()
        {
            Title = TitleBox.Text.Trim(),
            Content = ContentBox.Text,
            Created = DateBox.SelectedDate ?? DateTime.Today
        };
        notes.Add(note);
        NotesList.SelectedItem = note;
        SaveNotes();
    }

    private void Save_Click(object sender, RoutedEventArgs e)
    {
        if (NotesList.SelectedItem is not Note note)
        {
            MessageBox.Show("Выберите заметку для сохранения.", "Заметки");
            return;
        }
        if (!CheckTitle())
            return;

        note.Title = TitleBox.Text.Trim();
        note.Content = ContentBox.Text;
        note.Created = DateBox.SelectedDate ?? DateTime.Today;
        NotesList.Items.Refresh();
        SaveNotes();
    }

    private void Delete_Click(object sender, RoutedEventArgs e)
    {
        if (NotesList.SelectedItem is Note note)
        {
            notes.Remove(note);
            ClearFields();
            SaveNotes();
        }
    }

    private void NotesList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (NotesList.SelectedItem is Note note)
        {
            TitleBox.Text = note.Title;
            ContentBox.Text = note.Content;
            DateBox.SelectedDate = note.Created;
        }
    }

    private void Clear_Click(object sender, RoutedEventArgs e)
    {
        ClearFields();
    }

    private void ClearFields()
    {
        NotesList.SelectedItem = null;
        TitleBox.Clear();
        ContentBox.Clear();
        DateBox.SelectedDate = DateTime.Today;
        TitleBox.Focus();
    }
}
