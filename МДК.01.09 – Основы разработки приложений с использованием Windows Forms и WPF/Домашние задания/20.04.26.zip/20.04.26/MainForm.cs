﻿namespace CurrencyConverter;

public class MainForm : Form
{
    private readonly Dictionary<string, decimal> rates = new()
    {
        { "RUB", 1m },
        { "USD", 84.3414m },
        { "EUR", 95.8709m },
        { "CNY", 12.5355m }
    };

    private readonly NumericUpDown amountInput = new();
    private readonly ComboBox fromCurrency = new();
    private readonly ComboBox toCurrency = new();
    private readonly Label resultLabel = new();

    public MainForm()
    {
        Text = "Конвертер валют";
        ClientSize = new Size(390, 330);
        AutoScaleDimensions = new SizeF(7, 15);
        AutoScaleMode = AutoScaleMode.Font;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;

        Label dateLabel = new();
        dateLabel.Text = "Фиксированные курсы ЦБ на 26.09.2026";
        dateLabel.SetBounds(20, 15, 350, 25);
        Controls.Add(dateLabel);

        Label ratesLabel = new();
        ratesLabel.Text = "1 USD = 84,3414 RUB\n1 EUR = 95,8709 RUB\n1 CNY = 12,5355 RUB";
        ratesLabel.SetBounds(20, 45, 350, 65);
        Controls.Add(ratesLabel);

        Label amountLabel = new();
        amountLabel.Text = "Сумма:";
        amountLabel.SetBounds(20, 123, 90, 25);
        Controls.Add(amountLabel);

        amountInput.SetBounds(120, 120, 250, 25);
        amountInput.DecimalPlaces = 2;
        amountInput.Maximum = 1000000000;
        amountInput.Value = 100;
        amountInput.TabIndex = 0;
        Controls.Add(amountInput);

        Label fromLabel = new();
        fromLabel.Text = "Из валюты:";
        fromLabel.SetBounds(20, 163, 90, 25);
        Controls.Add(fromLabel);

        fromCurrency.SetBounds(120, 160, 250, 25);
        fromCurrency.DropDownStyle = ComboBoxStyle.DropDownList;
        fromCurrency.Items.AddRange(rates.Keys.ToArray());
        fromCurrency.SelectedIndex = 1;
        fromCurrency.TabIndex = 1;
        Controls.Add(fromCurrency);

        Label toLabel = new();
        toLabel.Text = "В валюту:";
        toLabel.SetBounds(20, 203, 90, 25);
        Controls.Add(toLabel);

        toCurrency.SetBounds(120, 200, 250, 25);
        toCurrency.DropDownStyle = ComboBoxStyle.DropDownList;
        toCurrency.Items.AddRange(rates.Keys.ToArray());
        toCurrency.SelectedIndex = 0;
        toCurrency.TabIndex = 2;
        Controls.Add(toCurrency);

        Button convertButton = new();
        convertButton.Text = "Конвертировать";
        convertButton.SetBounds(120, 240, 250, 30);
        convertButton.TabIndex = 3;
        convertButton.Click += ConvertCurrency;
        Controls.Add(convertButton);
        AcceptButton = convertButton;

        resultLabel.SetBounds(20, 290, 350, 25);
        resultLabel.Text = "Результат:";
        Controls.Add(resultLabel);
        amountInput.ValueChanged += ClearResult;
        fromCurrency.SelectedIndexChanged += ClearResult;
        toCurrency.SelectedIndexChanged += ClearResult;
    }

    private void ConvertCurrency(object? sender, EventArgs e)
    {
        decimal result = amountInput.Value * rates[fromCurrency.Text] / rates[toCurrency.Text];
        resultLabel.Text = $"Результат: {result:N2} {toCurrency.Text}";
    }

    private void ClearResult(object? sender, EventArgs e)
    {
        resultLabel.Text = "Результат:";
    }
}
