﻿namespace WinFormsHomework;

partial class Form1
{
    private System.ComponentModel.IContainer components = null;

    private Label fromLabel;
    private TextBox fromTextBox;
    private Label toLabel;
    private TextBox toTextBox;
    private Label phoneLabel;
    private TextBox phoneTextBox;
    private Button orderButton;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }


    private void InitializeComponent()
    {
        fromLabel = new Label();
        fromTextBox = new TextBox();
        toLabel = new Label();
        toTextBox = new TextBox();
        phoneLabel = new Label();
        phoneTextBox = new TextBox();
        orderButton = new Button();
        SuspendLayout();

        fromLabel.AutoSize = true;
        fromLabel.Location = new Point(20, 23);
        fromLabel.Text = "Откуда:";

        fromTextBox.Location = new Point(100, 20);
        fromTextBox.Size = new Size(240, 23);
        fromTextBox.TabIndex = 0;

        toLabel.AutoSize = true;
        toLabel.Location = new Point(20, 63);
        toLabel.Text = "Куда:";

        toTextBox.Location = new Point(100, 60);
        toTextBox.Size = new Size(240, 23);
        toTextBox.TabIndex = 1;

        phoneLabel.AutoSize = true;
        phoneLabel.Location = new Point(20, 103);
        phoneLabel.Text = "Телефон:";

        phoneTextBox.Location = new Point(100, 100);
        phoneTextBox.Size = new Size(240, 23);
        phoneTextBox.TabIndex = 2;

        orderButton.Location = new Point(100, 145);
        orderButton.Size = new Size(240, 35);
        orderButton.TabIndex = 3;
        orderButton.Text = "Заказать такси";
        orderButton.UseVisualStyleBackColor = true;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(360, 200);
        Controls.Add(fromLabel);
        Controls.Add(fromTextBox);
        Controls.Add(toLabel);
        Controls.Add(toTextBox);
        Controls.Add(phoneLabel);
        Controls.Add(phoneTextBox);
        Controls.Add(orderButton);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Заказ такси";
        ResumeLayout(false);
        PerformLayout();
    }

}
