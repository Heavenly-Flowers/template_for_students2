﻿using System.Windows;

namespace LoanCalculator;

public partial class App : Application
{
}
