﻿using System.Globalization;
using System.Windows;
using System.Windows.Controls;

namespace LoanCalculator;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void Calculate_Click(object sender, RoutedEventArgs e)
    {
        bool validAmount = double.TryParse(AmountBox.Text.Trim().Replace(',', '.'),
            NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out double amount);
        bool validRate = double.TryParse(RateBox.Text.Trim().Replace(',', '.'),
            NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out double rate);
        bool validMonths = int.TryParse(MonthsBox.Text, out int months);

        if (!validAmount || amount <= 0 || amount > 1000000000 ||
            !validRate || rate < 0 || rate > 100 ||
            !validMonths || months < 1 || months > 600)
        {
            MessageBox.Show("Введите сумму больше 0 и до 1 000 000 000 ₽,\n" +
                "ставку от 0 до 100% и срок от 1 до 600 месяцев.", "Проверьте данные");
            return;
        }

        double payment = Credit.CalculatePayment(amount, rate, months);
        double total = payment * months;
        var culture = CultureInfo.GetCultureInfo("ru-RU");
        PaymentText.Text = $"Ежемесячный платёж: {payment.ToString("N2", culture)} ₽";
        TotalText.Text = $"Общая выплата: {total.ToString("N2", culture)} ₽";
        OverpaymentText.Text = $"Переплата: {(total - amount).ToString("N2", culture)} ₽";
    }

    private void InputChanged(object sender, TextChangedEventArgs e)
    {
        if (PaymentText == null || TotalText == null || OverpaymentText == null)
            return;

        PaymentText.Text = "Ежемесячный платёж: —";
        TotalText.Text = "Общая выплата: —";
        OverpaymentText.Text = "Переплата: —";
    }
}
