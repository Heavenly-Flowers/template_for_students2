﻿namespace LoanCalculator;

public static class Credit
{
    public static double CalculatePayment(double amount, double annualRate, int months)
    {
        double monthlyRate = annualRate / 1200;
        if (monthlyRate == 0)
            return amount / months;

        double factor = 0;
        for (int month = 0; month < months; month++)
            factor = (factor + 1) / (1 + monthlyRate);

        return amount / factor;
    }
}
