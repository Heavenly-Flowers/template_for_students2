﻿using System.Globalization;
using System.Windows;
using System.Windows.Controls;

namespace WeeklyExpenses;

public partial class MainWindow : Window
{
    private readonly TextBox[] fields;

    public MainWindow()
    {
        InitializeComponent();
        fields = new[] { MondayBox, TuesdayBox, WednesdayBox, ThursdayBox,
            FridayBox, SaturdayBox, SundayBox };
    }

    private void Calculate_Click(object sender, RoutedEventArgs e)
    {
        decimal[] expenses = new decimal[7];
        for (int i = 0; i < fields.Length; i++)
        {
            decimal.TryParse(fields[i].Text.Trim().Replace(',', '.'),
                NumberStyles.AllowLeadingSign | NumberStyles.AllowDecimalPoint,
                CultureInfo.InvariantCulture, out expenses[i]);
        }

        try
        {
            decimal total = expenses.Sum();
            decimal average = total / 7;
            decimal maximum = expenses.Max();
            var culture = CultureInfo.GetCultureInfo("ru-RU");
            TotalText.Text = $"Сумма за неделю: {total.ToString("N2", culture)}";
            AverageText.Text = $"Средний расход в день: {average.ToString("N2", culture)}";
            MaximumText.Text = $"Максимум за день: {maximum.ToString("N2", culture)}";
        }
        catch (OverflowException)
        {
            TotalText.Text = "Сумма слишком большая для расчёта";
            AverageText.Text = "Средний расход в день: —";
            MaximumText.Text = "Максимум за день: —";
        }
    }

    private void Clear_Click(object sender, RoutedEventArgs e)
    {
        foreach (TextBox field in fields)
            field.Clear();

        TotalText.Text = "Сумма за неделю: 0,00";
        AverageText.Text = "Средний расход в день: 0,00";
        MaximumText.Text = "Максимум за день: 0,00";
        MondayBox.Focus();
    }
}
