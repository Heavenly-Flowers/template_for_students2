﻿using System.Windows;

namespace WeeklyExpenses;

public partial class App : Application
{
}
