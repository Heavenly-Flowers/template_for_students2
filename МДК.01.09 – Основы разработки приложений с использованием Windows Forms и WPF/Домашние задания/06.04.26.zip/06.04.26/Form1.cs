﻿namespace PizzaOrder;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }

    private void orderButton_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrWhiteSpace(addressTextBox.Text) ||
            string.IsNullOrWhiteSpace(phoneTextBox.Text))
        {
            MessageBox.Show("Введите адрес и телефон.", "Заказ пиццы");
            return;
        }

        MessageBox.Show(
            $"Пицца: {pizzaComboBox.Text}\nКоличество: {quantityNumeric.Value}\n" +
            $"Адрес: {addressTextBox.Text}\nТелефон: {phoneTextBox.Text}",
            "Ваш заказ");
    }
}
