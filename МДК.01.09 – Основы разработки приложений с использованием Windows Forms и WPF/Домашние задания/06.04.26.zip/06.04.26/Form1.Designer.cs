﻿namespace PizzaOrder;

partial class Form1
{
    private System.ComponentModel.IContainer components = null;
    private Label pizzaLabel;
    private ComboBox pizzaComboBox;
    private Label quantityLabel;
    private NumericUpDown quantityNumeric;
    private Label addressLabel;
    private TextBox addressTextBox;
    private Label phoneLabel;
    private TextBox phoneTextBox;
    private Button orderButton;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null)
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        pizzaLabel = new Label();
        pizzaComboBox = new ComboBox();
        quantityLabel = new Label();
        quantityNumeric = new NumericUpDown();
        addressLabel = new Label();
        addressTextBox = new TextBox();
        phoneLabel = new Label();
        phoneTextBox = new TextBox();
        orderButton = new Button();
        ((System.ComponentModel.ISupportInitialize)quantityNumeric).BeginInit();
        SuspendLayout();

        pizzaLabel.AutoSize = true;
        pizzaLabel.Location = new Point(20, 23);
        pizzaLabel.Text = "Пицца:";

        pizzaComboBox.Location = new Point(120, 20);
        pizzaComboBox.Size = new Size(230, 23);
        pizzaComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
        pizzaComboBox.Items.AddRange(new object[] { "Маргарита", "Пепперони", "Четыре сыра" });
        pizzaComboBox.SelectedIndex = 0;
        pizzaComboBox.TabIndex = 0;

        quantityLabel.AutoSize = true;
        quantityLabel.Location = new Point(20, 63);
        quantityLabel.Text = "Количество:";

        quantityNumeric.Location = new Point(120, 60);
        quantityNumeric.Size = new Size(230, 23);
        quantityNumeric.Minimum = 1;
        quantityNumeric.Maximum = 100;
        quantityNumeric.Value = 1;
        quantityNumeric.TabIndex = 1;

        addressLabel.AutoSize = true;
        addressLabel.Location = new Point(20, 103);
        addressLabel.Text = "Адрес:";

        addressTextBox.Location = new Point(120, 100);
        addressTextBox.Size = new Size(230, 23);
        addressTextBox.TabIndex = 2;

        phoneLabel.AutoSize = true;
        phoneLabel.Location = new Point(20, 143);
        phoneLabel.Text = "Телефон:";

        phoneTextBox.Location = new Point(120, 140);
        phoneTextBox.Size = new Size(230, 23);
        phoneTextBox.TabIndex = 3;

        orderButton.Location = new Point(120, 185);
        orderButton.Size = new Size(230, 35);
        orderButton.Text = "Заказать пиццу";
        orderButton.TabIndex = 4;
        orderButton.UseVisualStyleBackColor = true;
        orderButton.Click += orderButton_Click;

        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(370, 240);
        Controls.Add(pizzaLabel);
        Controls.Add(pizzaComboBox);
        Controls.Add(quantityLabel);
        Controls.Add(quantityNumeric);
        Controls.Add(addressLabel);
        Controls.Add(addressTextBox);
        Controls.Add(phoneLabel);
        Controls.Add(phoneTextBox);
        Controls.Add(orderButton);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        Text = "Заказ пиццы";
        ((System.ComponentModel.ISupportInitialize)quantityNumeric).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }
}
