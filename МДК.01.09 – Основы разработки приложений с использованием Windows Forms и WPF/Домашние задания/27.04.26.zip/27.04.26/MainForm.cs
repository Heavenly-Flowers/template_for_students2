﻿using System.Runtime.InteropServices;

namespace ComputerMonitor;

public class MainForm : Form
{
    private readonly Label cpuLabel = new();
    private readonly Label memoryLabel = new();
    private readonly Label diskLabel = new();
    private readonly ProgressBar cpuBar = new();
    private readonly ProgressBar memoryBar = new();
    private readonly ProgressBar diskBar = new();
    private readonly System.Windows.Forms.Timer timer = new();
    private ulong previousIdle;
    private ulong previousTotal;
    private bool hasCpuSample;

    public MainForm()
    {
        Text = "Состояние компьютера";
        ClientSize = new Size(440, 300);
        AutoScaleDimensions = new SizeF(7, 15);
        AutoScaleMode = AutoScaleMode.Font;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;

        Label computerLabel = new();
        computerLabel.Text = $"Компьютер: {Environment.MachineName}";
        computerLabel.SetBounds(20, 15, 400, 25);
        Controls.Add(computerLabel);

        cpuLabel.SetBounds(20, 50, 400, 25);
        cpuBar.SetBounds(20, 80, 400, 20);
        memoryLabel.SetBounds(20, 115, 400, 25);
        memoryBar.SetBounds(20, 145, 400, 20);
        diskLabel.SetBounds(20, 180, 400, 40);
        diskBar.SetBounds(20, 225, 400, 20);
        Controls.AddRange(new Control[]
        {
            cpuLabel, cpuBar, memoryLabel, memoryBar, diskLabel, diskBar
        });

        Label updateLabel = new();
        updateLabel.Text = "Обновление каждую секунду";
        updateLabel.SetBounds(20, 265, 400, 25);
        Controls.Add(updateLabel);

        UpdateStatus();
        timer.Interval = 1000;
        timer.Tick += (sender, e) => UpdateStatus();
        timer.Start();
    }

    private void UpdateStatus()
    {
        if (GetSystemTimes(out ulong idle, out ulong kernel, out ulong user))
        {
            ulong total = kernel + user;
            if (hasCpuSample && total > previousTotal)
            {
                double load = 100.0 * (1 - (double)(idle - previousIdle) / (total - previousTotal));
                load = Math.Clamp(load, 0, 100);
                cpuLabel.Text = $"Загрузка процессора: {load:F1}%";
                cpuBar.Value = (int)Math.Round(load);
            }
            else
            {
                cpuLabel.Text = "Загрузка процессора: измерение...";
            }
            previousIdle = idle;
            previousTotal = total;
            hasCpuSample = true;
        }
        else
        {
            cpuLabel.Text = "Загрузка процессора: недоступна";
            cpuBar.Value = 0;
            hasCpuSample = false;
        }

        MemoryStatus memory = new();
        memory.Length = (uint)Marshal.SizeOf<MemoryStatus>();
        if (GlobalMemoryStatusEx(ref memory))
        {
            double total = memory.TotalPhysical / 1073741824.0;
            double used = (memory.TotalPhysical - memory.AvailablePhysical) / 1073741824.0;
            memoryLabel.Text = $"Оперативная память: {used:F1} из {total:F1} ГБ ({memory.Load}%)";
            memoryBar.Value = (int)Math.Min(memory.Load, 100u);
        }
        else
        {
            memoryLabel.Text = "Оперативная память: недоступна";
            memoryBar.Value = 0;
        }

        try
        {
            DriveInfo drive = new(Path.GetPathRoot(Environment.SystemDirectory)!);
            long total = drive.TotalSize;
            long free = drive.TotalFreeSpace;
            double usedPercent = 100.0 * (total - free) / total;
            diskLabel.Text = $"Диск {drive.Name} — занято {usedPercent:F1}%\n" +
                $"Свободно: {free / 1073741824.0:F1} из {total / 1073741824.0:F1} ГБ";
            diskBar.Value = (int)Math.Clamp(Math.Round(usedPercent), 0, 100);
        }
        catch (IOException)
        {
            diskLabel.Text = "Информация о диске недоступна";
            diskBar.Value = 0;
        }
        catch (UnauthorizedAccessException)
        {
            diskLabel.Text = "Нет доступа к информации о диске";
            diskBar.Value = 0;
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
            timer.Dispose();
        base.Dispose(disposing);
    }

    [DllImport("kernel32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetSystemTimes(out ulong idle, out ulong kernel, out ulong user);

    [DllImport("kernel32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx(ref MemoryStatus status);

    [StructLayout(LayoutKind.Sequential)]
    private struct MemoryStatus
    {
        public uint Length;
        public uint Load;
        public ulong TotalPhysical;
        public ulong AvailablePhysical;
        public ulong TotalPageFile;
        public ulong AvailablePageFile;
        public ulong TotalVirtual;
        public ulong AvailableVirtual;
        public ulong AvailableExtendedVirtual;
    }
}
