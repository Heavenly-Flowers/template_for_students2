from flask import Flask, abort, flash, redirect, render_template, session, url_for

app = Flask(__name__)
app.config["SECRET_KEY"] = "mini-shop-session-key"

PRODUCTS = [
    {"id": 1, "name": "Беспроводные наушники", "price": 4990, "category": "Электроника"},
    {"id": 2, "name": "Смарт-часы", "price": 8990, "category": "Электроника"},
    {"id": 3, "name": "Рюкзак городской", "price": 3490, "category": "Аксессуары"},
    {"id": 4, "name": "Термокружка", "price": 1290, "category": "Для дома"},
    {"id": 5, "name": "Настольная лампа", "price": 2790, "category": "Для дома"},
    {"id": 6, "name": "Футболка базовая", "price": 1590, "category": "Одежда"},
]


def get_cart_items():
    cart = session.get("cart", {})
    items = []
    for product in PRODUCTS:
        quantity = cart.get(str(product["id"]), 0)
        if quantity:
            item = product.copy()
            item["quantity"] = quantity
            item["sum"] = product["price"] * quantity
            items.append(item)
    return items


@app.template_filter("price")
def format_price(value):
    return f"{value:,.0f}".replace(",", " ")


@app.context_processor
def inject_cart_count():
    cart = session.get("cart", {})
    return {"cart_count": sum(cart.values())}


@app.get("/")
def index():
    return render_template("index.html", products=PRODUCTS)


@app.post("/cart/add/<int:product_id>")
def add_to_cart(product_id):
    product = next((product for product in PRODUCTS if product["id"] == product_id), None)
    if product is None:
        abort(404)
    cart = session.get("cart", {})
    product_key = str(product_id)
    cart[product_key] = cart.get(product_key, 0) + 1
    session["cart"] = cart
    flash(f"«{product['name']}» добавлен в корзину", "success")
    return redirect(url_for("index"))


@app.get("/cart")
def cart():
    items = get_cart_items()
    total = sum(item["sum"] for item in items)
    total_quantity = sum(item["quantity"] for item in items)
    return render_template(
        "cart.html",
        items=items,
        total=total,
        total_quantity=total_quantity,
        unique_positions=len(items),
    )


@app.post("/cart/remove/<int:product_id>")
def remove_from_cart(product_id):
    cart = session.get("cart", {})
    product = next((product for product in PRODUCTS if product["id"] == product_id), None)
    if product is None:
        abort(404)
    if cart.pop(str(product_id), None) is not None:
        session["cart"] = cart
        flash(f"«{product['name']}» удалён из корзины", "success")
    return redirect(url_for("cart"))


@app.post("/cart/clear")
def clear_cart():
    session.pop("cart", None)
    flash("Корзина очищена", "success")
    return redirect(url_for("cart"))


if __name__ == "__main__":
    app.run(debug=True)
