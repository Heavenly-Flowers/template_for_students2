import sqlite3
from pathlib import Path

from flask import Flask, abort, flash, g, redirect, render_template, request, url_for

app = Flask(__name__)
app.config["SECRET_KEY"] = "task-manager-secret-key"
app.config["DATABASE"] = str(Path(__file__).with_name("tasks.db"))

CATEGORIES = ("Работа", "Учёба", "Личное", "Дом", "Другое")
SORTING = {
    "newest": "id DESC",
    "active_first": "done ASC, id DESC",
    "done_first": "done DESC, id DESC",
}


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(error):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    db = get_db()
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            done BOOLEAN NOT NULL DEFAULT 0,
            category TEXT NOT NULL
        )
        """
    )
    db.commit()


def get_task(task_id):
    task = get_db().execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
    if task is None:
        abort(404)
    return task


def validate_form():
    title = request.form.get("title", "").strip()
    description = request.form.get("description", "").strip()
    category = request.form.get("category", "")
    if not title:
        flash("Введите название задачи", "error")
        return None
    if category not in CATEGORIES:
        flash("Выберите категорию", "error")
        return None
    return title, description, category


def redirect_to_tasks():
    return redirect(
        url_for(
            "index",
            category=request.form.get("category", ""),
            sort=request.form.get("sort", "active_first"),
        )
    )


@app.get("/")
def index():
    selected_category = request.args.get("category", "")
    sort = request.args.get("sort", "active_first")
    if sort not in SORTING:
        sort = "active_first"

    query = "SELECT * FROM tasks"
    params = []
    if selected_category:
        query += " WHERE category = ?"
        params.append(selected_category)
    query += f" ORDER BY {SORTING[sort]}"

    db = get_db()
    tasks = db.execute(query, params).fetchall()
    stats = db.execute(
        "SELECT COUNT(*) AS total, COALESCE(SUM(done), 0) AS completed FROM tasks"
    ).fetchone()
    return render_template(
        "index.html",
        tasks=tasks,
        categories=CATEGORIES,
        selected_category=selected_category,
        sort=sort,
        total=stats["total"],
        completed=stats["completed"],
        active=stats["total"] - stats["completed"],
    )


@app.post("/add")
def add_task():
    form = validate_form()
    if form is None:
        return redirect(url_for("index"))
    title, description, category = form
    db = get_db()
    db.execute(
        "INSERT INTO tasks (title, description, category) VALUES (?, ?, ?)",
        (title, description, category),
    )
    db.commit()
    flash("Задача добавлена", "success")
    return redirect(url_for("index"))


@app.route("/edit/<int:task_id>", methods=("GET", "POST"))
def edit_task(task_id):
    task = get_task(task_id)
    if request.method == "POST":
        form = validate_form()
        if form is None:
            return render_template("edit.html", task=task, categories=CATEGORIES)
        title, description, category = form
        db = get_db()
        db.execute(
            "UPDATE tasks SET title = ?, description = ?, category = ? WHERE id = ?",
            (title, description, category, task_id),
        )
        db.commit()
        flash("Задача обновлена", "success")
        return redirect(url_for("index"))
    return render_template("edit.html", task=task, categories=CATEGORIES)


@app.post("/toggle/<int:task_id>")
def toggle_task(task_id):
    get_task(task_id)
    db = get_db()
    db.execute("UPDATE tasks SET done = NOT done WHERE id = ?", (task_id,))
    db.commit()
    return redirect_to_tasks()


@app.post("/delete/<int:task_id>")
def delete_task(task_id):
    get_task(task_id)
    db = get_db()
    db.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
    db.commit()
    flash("Задача удалена", "success")
    return redirect_to_tasks()


with app.app_context():
    init_db()

if __name__ == "__main__":
    app.run(debug=True)
