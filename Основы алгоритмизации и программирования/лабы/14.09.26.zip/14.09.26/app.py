from flask import Flask, render_template
from flask_wtf import FlaskForm
from wtforms import FloatField, IntegerField, SubmitField
from wtforms.validators import DataRequired, NumberRange

app = Flask(__name__)
app.config["SECRET_KEY"] = "bmi-calculator-secret-key"


class BmiForm(FlaskForm):
    weight = FloatField(
        "Вес (кг)",
        validators=[
            DataRequired(message="Введите вес."),
            NumberRange(min=20, max=300, message="Вес должен быть от 20 до 300 кг.")
        ]
    )
    height = IntegerField(
        "Рост (см)",
        validators=[
            DataRequired(message="Введите рост."),
            NumberRange(min=100, max=250, message="Рост должен быть от 100 до 250 см.")
        ]
    )
    age = IntegerField(
        "Возраст",
        validators=[
            DataRequired(message="Введите возраст."),
            NumberRange(min=1, max=120, message="Возраст должен быть от 1 до 120 лет.")
        ]
    )
    submit = SubmitField("Рассчитать ИМТ")


@app.get("/")
def index():
    form = BmiForm()
    return render_template("index.html", form=form)


@app.post("/calculate")
def calculate():
    form = BmiForm()

    if not form.validate_on_submit():
        return render_template("index.html", form=form), 400

    weight = form.weight.data
    height = form.height.data
    age = form.age.data
    bmi = weight / (height / 100) ** 2

    if bmi < 18.5:
        category = "Недовес"
    elif bmi < 25:
        category = "Норма"
    elif bmi < 30:
        category = "Избыточный вес"
    else:
        category = "Ожирение"

    return render_template(
        "result.html",
        bmi=round(bmi, 1),
        category=category,
        weight=weight,
        height=height,
        age=age
    )


if __name__ == "__main__":
    app.run(debug=True)
