from datetime import datetime, timedelta, timezone
from pathlib import Path

from flask import Flask, flash, redirect, render_template, session, url_for
from flask_session import Session
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import CSRFProtect, FlaskForm
from sqlalchemy import or_
from werkzeug.security import check_password_hash, generate_password_hash
from wtforms import EmailField, PasswordField, StringField, SubmitField
from wtforms.validators import DataRequired, Email, Length, Regexp

BASE_DIR = Path(__file__).resolve().parent

app = Flask(__name__)
app.config["SECRET_KEY"] = "flask-sqlite-auth-secret-key"
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{BASE_DIR / 'users.db'}"
app.config["SQLALCHEMY_BINDS"] = {
    "sessions": f"sqlite:///{BASE_DIR / 'sessions.db'}"
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SESSION_TYPE"] = "sqlalchemy"
app.config["SESSION_PERMANENT"] = True
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=7)
app.config["SESSION_USE_SIGNER"] = True
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_SQLALCHEMY_BIND_KEY"] = "sessions"

db = SQLAlchemy()
csrf = CSRFProtect(app)


class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(30), unique=True, nullable=False, index=True)
    email = db.Column(db.String(254), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    created_at = db.Column(
        db.DateTime(timezone=True),
        nullable=False,
        default=lambda: datetime.now(timezone.utc),
    )


class RegisterForm(FlaskForm):
    username = StringField(
        "Имя пользователя",
        validators=[
            DataRequired(message="Введите имя пользователя"),
            Length(min=3, max=30, message="Имя должно содержать от 3 до 30 символов"),
            Regexp(
                r"^[A-Za-zА-Яа-я0-9_.-]+$",
                message="Используйте буквы, цифры, точку, дефис или подчёркивание",
            ),
        ],
    )
    email = EmailField(
        "Email",
        validators=[
            DataRequired(message="Введите email"),
            Email(message="Введите корректный email", check_deliverability=False),
        ],
    )
    password = PasswordField(
        "Пароль",
        validators=[
            DataRequired(message="Введите пароль"),
            Length(min=6, max=128, message="Пароль должен содержать не менее 6 символов"),
        ],
    )
    submit = SubmitField("Зарегистрироваться")


class LoginForm(FlaskForm):
    username = StringField(
        "Имя пользователя",
        validators=[DataRequired(message="Введите имя пользователя")],
    )
    password = PasswordField(
        "Пароль",
        validators=[DataRequired(message="Введите пароль")],
    )
    submit = SubmitField("Войти")


class LogoutForm(FlaskForm):
    submit = SubmitField("Выйти")


def get_current_user():
    user_id = session.get("user_id")
    if user_id is None:
        return None
    user = db.session.get(User, user_id)
    if user is None:
        session.clear()
    return user


def authenticate(user):
    session.clear()
    session["user_id"] = user.id
    session.permanent = True


db.init_app(app)
app.config["SESSION_SQLALCHEMY"] = db
with app.app_context():
    db.create_all()
Session(app)


@app.get("/")
def index():
    if get_current_user():
        return redirect(url_for("profile"))
    return redirect(url_for("login"))


@app.route("/register", methods=("GET", "POST"))
def register():
    if get_current_user():
        return redirect(url_for("profile"))
    form = RegisterForm()
    if form.validate_on_submit():
        username = form.username.data.strip()
        email = form.email.data.strip().lower()
        existing_user = User.query.filter(
            or_(
                db.func.lower(User.username) == username.lower(),
                db.func.lower(User.email) == email,
            )
        ).first()
        if existing_user:
            if existing_user.username.lower() == username.lower():
                form.username.errors.append("Это имя пользователя уже занято")
            else:
                form.email.errors.append("Этот email уже зарегистрирован")
        else:
            user = User(
                username=username,
                email=email,
                password_hash=generate_password_hash(form.password.data),
            )
            db.session.add(user)
            db.session.commit()
            authenticate(user)
            flash("Регистрация успешно завершена", "success")
            return redirect(url_for("profile"))
    return render_template("register.html", form=form)


@app.route("/login", methods=("GET", "POST"))
def login():
    if get_current_user():
        return redirect(url_for("profile"))
    form = LoginForm()
    if form.validate_on_submit():
        username = form.username.data.strip()
        user = User.query.filter(db.func.lower(User.username) == username.lower()).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            authenticate(user)
            flash("Вы успешно вошли в аккаунт", "success")
            return redirect(url_for("profile"))
        flash("Неверное имя пользователя или пароль", "error")
    return render_template("login.html", form=form)


@app.get("/profile")
def profile():
    user = get_current_user()
    if user is None:
        flash("Войдите в аккаунт, чтобы открыть профиль", "error")
        return redirect(url_for("login"))
    return render_template("profile.html", user=user, logout_form=LogoutForm())


@app.post("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


if __name__ == "__main__":
    app.run(debug=True)
