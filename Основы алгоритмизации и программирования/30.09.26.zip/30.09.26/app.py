from flask import Flask, redirect, render_template, session, url_for

app = Flask(__name__)
app.config["SECRET_KEY"] = "visit-counter-session-key"


@app.get("/")
def index():
    visits = session.get("visits", 0) + 1
    session["visits"] = visits
    return render_template("index.html", visits=visits)


@app.post("/reset")
def reset():
    session["visits"] = 0
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(debug=True)
