from flask import Flask, abort, render_template

app = Flask(__name__)

movies = [
    {
        "id": 1,
        "title": "Начало",
        "year": 2010,
        "genre": "Фантастика",
        "rating": 8.8,
        "description": "Группа специалистов проникает в сны людей, чтобы извлекать или внедрять идеи."
    },
    {
        "id": 2,
        "title": "Интерстеллар",
        "year": 2014,
        "genre": "Фантастика",
        "rating": 8.7,
        "description": "Команда исследователей отправляется через кротовую нору в космосе в поисках нового дома для человечества."
    },
    {
        "id": 3,
        "title": "Побег из Шоушенка",
        "year": 1994,
        "genre": "Драма",
        "rating": 9.3,
        "description": "Банкир Энди Дюфрейн попадает в тюрьму, где находит друга и не теряет надежду на свободу."
    },
    {
        "id": 4,
        "title": "Зелёная книга",
        "year": 2018,
        "genre": "Драма",
        "rating": 8.4,
        "description": "Водитель и пианист отправляются в совместное путешествие, которое меняет их взгляды на жизнь."
    },
    {
        "id": 5,
        "title": "1+1",
        "year": 2011,
        "genre": "Комедия, драма",
        "rating": 8.8,
        "description": "История неожиданной дружбы богатого аристократа и его помощника из неблагополучного района."
    }
]


@app.route("/")
def index():
    return render_template("index.html", movies=movies)


@app.route("/movie/<int:movie_id>")
def movie(movie_id):
    selected_movie = None

    for item in movies:
        if item["id"] == movie_id:
            selected_movie = item
            break

    if selected_movie is None:
        abort(404)

    return render_template("movie.html", movie=selected_movie)


if __name__ == "__main__":
    app.run(debug=True)
